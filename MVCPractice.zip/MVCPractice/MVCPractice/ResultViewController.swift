//
//  ResultViewController.swift
//  MVCPractice
//
//  Created by Gantla,Achyutha Reddy on 4/4/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var lengthOutlet: UILabel!
    
    @IBOutlet weak var breadthOutlet: UILabel!
    
    @IBOutlet weak var perimeterOutlet: UILabel!
    
    var l = ""
    var b = ""
    var p = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lengthOutlet.text = lengthOutlet.text! + l
        breadthOutlet.text = breadthOutlet.text! + b
        perimeterOutlet.text = perimeterOutlet.text! + p
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
