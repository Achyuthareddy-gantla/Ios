//
//  ViewController.swift
//  Achyuweatherapp
//
//  Created by Gantla,Achyutha Reddy on 2/27/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var displaylabel: UILabel!
    
    @IBOutlet weak var tempoutlet: UITextField!
    
    
    @IBOutlet weak var imageview: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        
    }
    
    
    
    @IBAction func evaluatetemp(_ sender: UIButton) {
        
        var temp = Int(tempoutlet.text!)!
        
        if(temp == 0){
            
            imageview.image = UIImage(named: "freezy")
            displaylabel.text = " It is too cold"
            
            
        }else if(temp>=30) {
            
            imageview.image = UIImage(named: "sunny")
            displaylabel.text = "It is too hot"
        }else if(temp>=11 && temp<=20){
            imageview.image = UIImage(named: "rainy")
            displaylabel.text = "It's Raining"
        } else {
            imageview.image = UIImage(named: "snow")
            displaylabel.text = "It is snowing"
        }
    
    }
    
}
