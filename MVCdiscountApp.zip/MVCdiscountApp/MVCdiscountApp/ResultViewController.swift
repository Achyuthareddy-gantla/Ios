//
//  ResultViewController.swift
//  MVCdiscountApp
//
//  Created by Gantla,Achyutha Reddy on 3/30/23.
//

import UIKit

class ResultViewController: UIViewController {

    
   
    @IBOutlet weak var displayamountoulet: UILabel!
    
    
    
    
    @IBOutlet weak var displaydiscountoutlet: UILabel!
    
    
 
    
    
    @IBOutlet weak var displaypriceoutlet: UILabel!
    
    // need variables to store the values
    var destinationAmount = ""
    var destinationDiscrate = ""
    var result = ""
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        displayamountoulet.text! += destinationAmount
        displaydiscountoutlet.text! += destinationDiscrate
        displaypriceoutlet.text! += result
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
