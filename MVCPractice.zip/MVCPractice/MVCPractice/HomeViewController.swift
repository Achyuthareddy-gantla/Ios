//
//  ViewController.swift
//  MVCPractice
//
//  Created by Gantla,Achyutha Reddy on 4/4/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var lengthOL: UITextField!
    
    @IBOutlet weak var breadthOL: UITextField!
    
    var perimeter = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func findPerimeterBtn(_ sender: Any) {
        let length = Double(lengthOL.text!)
        let breadth = Double(breadthOL.text!)
        perimeter = 2*(length!+breadth!)
    }
        
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ResultSegue" {
            var destination = segue.destination as! ResultViewController
            destination.l = lengthOL.text!
            destination.b = breadthOL.text!
            destination.p = String(perimeter)
            lengthOL.text = ""
            breadthOL.text = ""
        }
        
        
        
    }
    
}
