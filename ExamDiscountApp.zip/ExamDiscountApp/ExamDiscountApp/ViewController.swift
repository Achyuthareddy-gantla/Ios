//
//  ViewController.swift
//  ExamDiscountApp
//
//  Created by Eladandi,Jayachandra S on 2/27/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var amount: UITextField!
    
    @IBOutlet weak var discount: UITextField!
    
    @IBOutlet weak var result: UILabel!
    
    
    @IBOutlet weak var imgView: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calculate(_ sender: UIButton) {
        var a = Double(amount.text!)!
        var b = Double(discount.text!)!
        var calPer = (a * b) / 100
        
        var dicAmlount = a - calPer
        
        result.text = "\(dicAmlount)"
        if(dicAmlount >= 1000) {
            imgView.image = UIImage(named: "high")
        } else if(dicAmlount > 500) {
            imgView.image = UIImage(named: "normal")
        } else {
            imgView.image = UIImage(named: "low")
        }
    }
    
    
    
    
    
    

}

