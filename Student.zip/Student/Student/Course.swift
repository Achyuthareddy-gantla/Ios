//
//  Course.swift
//  Student
//
//  Created by Gantla,Achyutha Reddy on 4/4/23.
//

import Foundation
