//
//  ViewController.swift
//  helloApp
//
//  Created by Gantla,Achyutha Reddy on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOutlet: UITextField!
    
    @IBOutlet weak var displaylabeloutlet: UILabel!
    
    @IBOutlet weak var inputoutlet1: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    //read the input from  the text field and store it in a local variable

    

    @IBAction func submitbuttonclicked(_ sender: Any) {
        var input = inputOutlet.text!;
        
        var input1 = inputoutlet1.text!;
        
        
        
        
        
        
        
        
        
        displaylabeloutlet.text = "hello, \(input) \(input1)!😍"
    }
    

}

