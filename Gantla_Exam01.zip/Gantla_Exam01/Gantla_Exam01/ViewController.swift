//
//  ViewController.swift
//  Gantla_Exam01
//
//  Created by Gantla,Achyutha Reddy on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var INRoutlet: UITextField!
    
    
    
    @IBOutlet weak var imageview: UIImageView!
    
    
    
    @IBOutlet weak var displaylabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        imageview.image = UIImage(named:"default")
        
        
    }
    
    @IBAction func USDBtn(_ sender: UIButton) {
        
        var amount = Double(INRoutlet.text!)
        
        if( amount == 0){
            displaylabel.text = "₹\(INRoutlet.text!) Oops! cannot convert"
            imageview.image = UIImage(named: "oops")
        }else {
            
            var usdvalue = Double(82.93)
            var cadvalue = Double(1.26 )
            var finalusdvalue = (amount!)/(usdvalue)
            var roundedvalue = (finalusdvalue*100)/100
            if(roundedvalue.description.lowercased() == usdvalue.description.lowercased() ){
               
               displaylabel.text = "₹\(amount) in USD is \(roundedvalue)"
               
               imageview.image = UIImage(named: "usd")
            }else{
                
                displaylabel.text = "₹\(INRoutlet.text!) Oops! cannot convert"
                imageview.image = UIImage(named: "oops")
                
            }
            displaylabel.text = "please enter some value"
            imageview.image = UIImage(named:"oops")
        }
    

    

}

    
    @IBAction func cadbtn(_ sender: Any) {
        
        
        var amount = Double(INRoutlet.text!)
      
        var cadvalue = Double(1.26 )
        var finalcadvalue = (amount!)/(cadvalue)
        var roundedvalue = (finalcadvalue*100)/100
        
        if( amount == 0){
            displaylabel.text = "₹\(INRoutlet.text!) Oops! cannot convert"
            imageview.image = UIImage(named: "oops")
        }else {
            
            var usdvalue = Double(82.93)
            var cadvalue = Double(1.26 )
            var finalusdvalue = (amount!)/(usdvalue)
        
            if(roundedvalue.description.lowercased() == usdvalue.description.lowercased() ){
               
               displaylabel.text = "₹\(amount) in cad is \(roundedvalue)"
               
               imageview.image = UIImage(named: "cad")
            }else{
                
                
                displaylabel.text = "please enter some value"
                imageview.image = UIImage(named:"oops")
            }
        }
    }
    
}

    
  


