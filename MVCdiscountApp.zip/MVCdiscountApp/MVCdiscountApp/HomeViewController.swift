//
//  ViewController.swift
//  MVCdiscountApp
//
//  Created by Gantla,Achyutha Reddy on 3/30/23.
//

import UIKit

class HomeViewController: UIViewController {

    
    
    @IBOutlet weak var amountoutlet: UITextField!
    

    
    @IBOutlet weak var discountrateoutlet: UITextField!
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    
    @IBAction func calculatebtn(_ sender: Any) {
        // read the text and convert it to double
        var amount = Double(amountoutlet.text!)!
        print(amount)
        var discrate = Double(discountrateoutlet.text!)!
        print(discrate)
        
        
        priceAfterDiscount = amount - (amount*discrate/100)
        print(priceAfterDiscount)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // create a transition
        var transition  =  segue.identifier
        if(transition == "resultSegue"){
            // create a destination
            var destination = segue.destination
            as! ResultViewController
            
            //assign values to esult view controller
            destination.destinationAmount  = amountoutlet.text!
            destination.destinationDiscrate = discountrateoutlet.text!
            destination.result = String(priceAfterDiscount)
        }
    }
    
}

