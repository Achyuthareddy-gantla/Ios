//
//  ThirdViewController.swift
//  BMIApp
//
//  Created by admin on 4/11/23.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var imageviewOutlet: UIImageView!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        imageviewOutlet.frame.origin.x = 76
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 3.0, delay: 0.1) {
            self.imageviewOutlet.frame.origin.x = 50
        }
    }

}
